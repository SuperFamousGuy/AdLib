<?php

$about_file = '<div class="vItem" style="text-align:center;margin-bottom:20px;"><div id="showVertexMsgWrap"><div id="progressBar"></div><div id="showVertexMsg"></div></div>';


?>