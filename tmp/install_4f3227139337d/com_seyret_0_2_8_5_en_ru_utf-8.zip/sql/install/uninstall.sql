DROP TABLE IF EXISTS `#__seyret_categories`;
DROP TABLE IF EXISTS `#__seyret_check`;
DROP TABLE IF EXISTS `#__seyret_items`;
DROP TABLE IF EXISTS `#__seyret_ads`;
DROP TABLE IF EXISTS `#__seyret_permissions`;
DROP TABLE IF EXISTS `#__seyret_reports`;
DROP TABLE IF EXISTS `#__seyret_imageads`;