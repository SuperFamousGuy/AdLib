UPDATE `#__seyret_check` SET dbversion='0.2.7.8' WHERE id='1';
