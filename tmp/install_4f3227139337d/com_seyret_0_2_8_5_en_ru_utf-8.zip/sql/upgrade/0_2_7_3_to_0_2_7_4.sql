UPDATE `#__seyret_check` SET dbversion='0.2.7.4' WHERE id='1';
ALTER TABLE #__seyret_items ADD COLUMN videotags TEXT;