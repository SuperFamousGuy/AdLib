UPDATE `#__seyret_check` SET dbversion='0.2.8.2' WHERE id='1';
UPDATE `#__seyret_check` SET accepttermsofuse='0' WHERE id='1';
