UPDATE `#__seyret_check` SET dbversion='0.2.3' WHERE id='1';
UPDATE `#__seyret_check` SET joomlaalemtrack='1' WHERE id='1';