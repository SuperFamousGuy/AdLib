<?php
$seyretversion="0.2.8.5";
$seyretversionname="[Zeynep]";
$seyretversionstatus="Bugfix release";
?>