			<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
		    <td width="14px"><div id="videotitleleft">&nbsp;</div></td>
		    <td><div id="videotitlemid">{commentstitle}</div></td>
		    <td width="14px"><div id="videotitleright">&nbsp;</div></td>
		  </tr>
		  <tr>
		    <td class="videotablelleft">&nbsp;</td>
		    <td>
				<div id="commentsscroll">
				{comments}
				</div>
			</td>
		    <td class="videotablelright">&nbsp;</td>
		  </tr>
		 <tr>
		    <td width="14px"><div id="videobottomleft">&nbsp;</div></td>
		    <td><div id="videobottommid">{seyretcredit}</div></td>
		    <td width="14px"><div id="videobottomright">&nbsp;</div></td>
		  </tr>
		</table>