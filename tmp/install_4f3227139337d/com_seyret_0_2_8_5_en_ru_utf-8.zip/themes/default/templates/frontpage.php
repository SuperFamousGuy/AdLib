<div>{toolbar}</div>
<br />
			{videodirectoriesheader}
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="seyrettemplatetable">
  <tr>
    <td width="1%" valign="top">
	
			{videomainarea}
			{seyretmod7}
	
			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="seyrettemplatetable">
		  <tr>
		    <td width="14px"><div id="videotitleleft">&nbsp;</div></td>
		    <td><div id="videotitlemid">{commentstitle}</div></td>
		    <td width="14px"><div id="videotitleright">&nbsp;</div></td>
		  </tr>
		  <tr>
		    <td class="videotablelleft">&nbsp;</td>
		    <td>
				<div id="commentsscroll">
				{comments}
				</div>
			</td>
		    <td class="videotablelright">&nbsp;</td>
		  </tr>
		 <tr>
		    <td width="14px"><div id="videobottomleft">&nbsp;</div></td>
		    <td><div id="videobottommid">&nbsp;</div></td>
		    <td width="14px"><div id="videobottomright">&nbsp;</div></td>
		  </tr>
		</table>

</td>
    <td valign="top" style="padding-left:5px;">

	
		<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="seyrettemplatetable">
		  <tr>
		    <td width="14px"><div id="videotitleleft">&nbsp;</div></td>
		    <td><div id="aboutthisvideo">{aboutthisvideotitle}</div></td>
		    <td width="14px"><div id="videotitleright">&nbsp;</div></td>
		  </tr>
		  <tr>
		    <td class="videotablelleft">&nbsp;</td>
		    <td>
							<table width="100%" border="0" cellspacing="5" cellpadding="0"  class="seyrettemplatetable">
                              


							  <tr>
								<td width="1%">{useravatar}</td><td>{addedby}</td>
                              </tr>
							</table>
							
							<table width="100%" border="0" cellspacing="5" cellpadding="0"  class="seyrettemplatetable">							  
                              <tr>
							    <td>{addeddate}</td>
                                <td>{totalhit}</td>
							</tr>
							<tr>							
                                <td>{totalvotes}</td>
                                <td>{rating}</td>
                              </tr>
                              <tr>
                                <td>{videovotearea}</td>
                                <td>&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">{showvideodetailsarea}</td>
                              </tr>  
                            </table>

							{videotags}{videourl}{videoembedcode}
			</td>
		    <td class="videotablelright">&nbsp;</td>
		  </tr>
		 <tr>
		    <td width="14px"><div id="videobottomleft">&nbsp;</div></td>
		    <td><div id="videobottommid">&nbsp;</div></td>
		    <td width="14px"><div id="videobottomright">&nbsp;</div></td>
		  </tr>
		</table>
		
    {videolistarea}
	</td>
  </tr>
</table>
<br/>



