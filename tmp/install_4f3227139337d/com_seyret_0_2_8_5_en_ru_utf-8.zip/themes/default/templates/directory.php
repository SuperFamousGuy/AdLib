<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="videodirectoryback">

  <tr>

    <td width="1%" rowspan="2" valign="top">{dirimage}</td>
    <td valign="top" height="1%">
      <div style="font-size:12px; font-weight:bold;">{dirname}</div>
	</td>
  </tr>
  <tr>
    <td rowspan="2" valign="top" style="padding-left:5px; font-size:9px; font-weight:bold; ">{dirsubcategories}</td>
  </tr>

</table>

