<div class="videolistdivintabs">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="14px"><div id="cattopleft">&nbsp;</div></td>
    <td><div id="cattopmid">&nbsp;</div></td>
    <td width="14px"><div id="cattopright">&nbsp;</div></td>
  </tr>
  <tr>
    <td class="catleft">&nbsp;</td>
    <td>

			<div id="categorynameinmainpage">{categorynameinmainpage}</div>

			
			<table width="100%" border="0" cellspacing="5" cellpadding="0"  class="seyrettemplatetable">
			<tr>
				<td valign="top"><div id="categorythumbnailinmainpage"><img src="{categorythumbnailsrcinmainpage}" class="categorythumbnailinmainpage" style="width:120px; height:90px;" alt=""/></div></td>
				<td valign="top"><div id="categorydescrinmainpage">{categorydescrinmainpage}</div></td>
			</tr>
			</table>


			
			
	
	</td>
    <td class="catright">&nbsp;</td>
  </tr>
  <tr>
    <td width="14px"><div id="catbotleft">&nbsp;</div></td>
    <td><div id="catbotmid"></div></td>
    <td width="14px"><div id="catbotright">&nbsp;</div></td>
  </tr>
</table>



</div>


