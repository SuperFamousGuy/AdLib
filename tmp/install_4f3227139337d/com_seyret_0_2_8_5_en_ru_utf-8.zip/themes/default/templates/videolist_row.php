	<td width="1%" valign="top" class="videolistleftcolumn">
		{videoscreen}
	</td>
	
	<td valign="top" class="videolistrightcolumn">
		<div class="titleinvideolist">{videotitle}</div>
		<div class="detailsinvideolist">{videoinfo}</div>
	</td>