<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="seyrettemplatetable">
  <tr>
    <td width="14px"><div id="videotitleleft">&nbsp;</div></td>
    <td><div id="videotitlemid">{videotitle}</div></td>
    <td width="14px"><div id="videotitleright">&nbsp;</div></td>
  </tr>
  <tr>
    <td class="videotablelleft">&nbsp;</td>
    <td>
		{embedvideoarea}
       <!-- Longtail api should be just under mediaspacediv, don't change tag position-->
	   {longtailapi}

	   
       {isareplyto} 
	</td>
    <td class="videotablelright">&nbsp;</td>
  </tr>
  <tr>
    <td class="videotablelleft">&nbsp;</td>
    <td>
	{videoreplies}				
	{videooperations}
	</td>
    
    
    <td class="videotablelright">&nbsp;</td>
  </tr>  
  <tr>
    <td width="14px"><div id="videobottomleft">&nbsp;</div></td>
    <td><div id="videobottommid">{bookmarks}</div></td>
    <td width="14px"><div id="videobottomright">&nbsp;</div></td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="seyrettemplatetable">
  <tr>
    <td valign="top">
		
</td>
</tr>
</table>