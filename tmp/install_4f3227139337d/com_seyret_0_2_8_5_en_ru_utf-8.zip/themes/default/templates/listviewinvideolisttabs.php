<div class="videolistdivintabs">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="14px"><div id="cattopleft">&nbsp;</div></td>
    <td><div id="cattopmid">&nbsp;</div></td>
    <td width="14px"><div id="cattopright">&nbsp;</div></td>
  </tr>
  <tr>
    <td class="catleft">&nbsp;</td>
    <td>
	
	<table width="100%" border="0" cellpadding="3">
		  <tr>
		    <td width="1%" rowspan="2" valign="top"><a href="{videolink}"><img src="{videothumbnailsrc}" class="videothumbnailinlists" /></a></td>
		    <td valign="top">
		    	<div class="videotitleintabbedlist"><a href="{videolink}">{videotitle}</a></div>
				<div class="videodetailsintabbedlist">{videodetails}</div>	</td>
		    <td width="1%" align="center" valign="top"><div style="padding:3px; text-align:center;">{useravatar}</div><div style="padding:3px; text-align:center;">{addedby}</div></td>
		  </tr>
		  <tr>
			<td><div id="addeddateinfrontlist">{addeddate}</div><div id="incategoryinfrontlist">{incategory}</div></td>
			<td><div style="padding:3px;">{votestars}</div></td>
		  </tr>
</table>

	</td>
    <td class="catright">&nbsp;</td>
  </tr>
  <tr>
    <td width="14px"><div id="catbotleft">&nbsp;</div></td>
    <td><div id="catbotmid"></div></td>
    <td width="14px"><div id="catbotright">&nbsp;</div></td>
  </tr>
</table>
</div>


