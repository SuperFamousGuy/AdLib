<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="seyrettemplatetable">
  <tr>
    <td width="14px"><div id="vlisttopleft">&nbsp;</div></td>
    <td><div id="vlisttopmid">{sortbykeys}{searchbox}</div></td>
    <td width="14px"><div id="vlisttopright">&nbsp;</div></td>
  </tr>
  <tr>
    <td class="videotablelleft">&nbsp;</td>
    <td>
		{navigation}
        
		<div id="videolistscroller">{videolistrows}</div>
        
	</td>
    <td class="videotablelright">&nbsp;</td>
  </tr>
  <tr>
    <td width="14px"><div id="videobottomleft">&nbsp;</div></td>
    <td><div id="videobottommid">
    	<table width="100%" cellpadding="0" cellspacing="0"  class="seyrettemplatetable"><tr><td>{pagenumber}</td><td width="1%" >{rssfeedforcategory}</td></tr></table> 
    
</div></td>
    <td width="14px"><div id="videobottomright">&nbsp;</div></td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
		
</td>
</tr>
</table>



