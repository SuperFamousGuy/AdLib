<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="seyrettemplatetable">
  <tr>
    <td width="14px"><div id="cattopleft">&nbsp;</div></td>
    <td><div id="cattopmid">&nbsp;</div></td>
    <td width="14px"><div id="cattopright">&nbsp;</div></td>
  </tr>
  <tr>
    <td class="catleft">&nbsp;</td>
    <td><span id="groupcontext">{categorylist}</span></td>
    <td class="catright">&nbsp;</td>
  </tr>
  <tr>
    <td width="14px"><div id="catbotleft">&nbsp;</div></td>
    <td><div id="catbotmid"></div></td>
    <td width="14px"><div id="catbotright">&nbsp;</div></td>
  </tr>
</table>

