  <tr style="border:1px solid #CCCCCC;">
    <td rowspan="4" width="10"><div align="center">{videothumbnail}</div></td>
    <td bordercolor="#999999" bgcolor="#EDEDED" style="padding:5px;">{videotitle}</td>
  </tr>
  <tr>
    <td>{description}</td>
  </tr>
  <tr>
    <td>{addeddatelabel}: {addeddate} - {addedbylabel}: {addedby}</td>
  </tr>
  <tr>
    <td>{hitlabel}: {hitcount} - {votecountlabel}: {votecount} - {ratinglabel}: {rating} </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
